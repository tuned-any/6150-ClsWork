
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function AddTodoForm() {
  const [title, setTitle] = useState("");
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const router = useRouter();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    const trimmed = title.trim();
    if (!trimmed) {
      setError("Please enter a todo title.");
      return;
    }
    if (trimmed.length > 200) {
      setError("Title must be 200 characters or fewer.");
      return;
    }

    setIsSubmitting(true);

    try {
      const res = await fetch("/api/todos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: trimmed }),
      });

      if (!res.ok) {
        const data = await res.json();
        setError(data.error || "Something went wrong.");
        return;
      }

      setTitle("");
      // Refresh the server component to show the new todo
      router.refresh();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="add-todo-card">
      <h2 className="add-todo-heading">Add a new todo</h2>

      {error && (
        <div className="error-banner">
          <svg className="error-icon" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
          </svg>
          {error}
        </div>
      )}

      <div className="form-row">
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="What needs to be done?"
          className="todo-input"
          maxLength={200}
          disabled={isSubmitting}
          onKeyDown={(e) => {
            if (e.key === "Enter") handleSubmit(e);
          }}
        />
        <button
          onClick={handleSubmit}
          disabled={isSubmitting || !title.trim()}
          className="submit-btn"
        >
          {isSubmitting ? (
            <svg className="spinner" viewBox="0 0 24 24" fill="none">
              <circle className="spinner-track" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" />
              <path className="spinner-arc" d="M12 2a10 10 0 019.95 9" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
            </svg>
          ) : (
            <>
              <svg className="plus-icon" fill="none" viewBox="0 0 24 24" strokeWidth="2.5" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
              </svg>
              Add
            </>
          )}
        </button>
      </div>

      <p className="char-count">
        {title.length}/200
      </p>
    </div>
  );
}
