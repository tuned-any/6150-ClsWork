
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

interface TodoItemProps {
  id: string;
  title: string;
  completed: boolean;
  createdAt: string;
}

export default function TodoItem({ id, title, completed, createdAt }: TodoItemProps) {
  const [isToggling, setIsToggling] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const router = useRouter();

  async function handleToggle() {
    setIsToggling(true);
    try {
      await fetch(`/api/todos/${id}`, { method: "PATCH" });
      router.refresh();
    } catch {
      console.error("Failed to toggle todo");
    } finally {
      setIsToggling(false);
    }
  }

  async function handleDelete() {
    setIsDeleting(true);
    try {
      await fetch(`/api/todos/${id}`, { method: "DELETE" });
      router.refresh();
    } catch {
      console.error("Failed to delete todo");
    } finally {
      setIsDeleting(false);
    }
  }

  const formattedDate = new Date(createdAt).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });

  return (
    <div className={`todo-item ${isDeleting ? "todo-deleting" : ""}`}>
      {/* Checkbox */}
      <button
        onClick={handleToggle}
        disabled={isToggling}
        className={`todo-checkbox ${completed ? "todo-checkbox-done" : "todo-checkbox-pending"}`}
        aria-label={completed ? "Mark as incomplete" : "Mark as complete"}
      >
        {completed && (
          <svg className="check-icon" fill="none" viewBox="0 0 24 24" strokeWidth="3" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
          </svg>
        )}
        {isToggling && (
          <svg className="spinner-sm" viewBox="0 0 24 24" fill="none">
            <path d="M12 2a10 10 0 019.95 9" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
          </svg>
        )}
      </button>

      {/* Content */}
      <div className="todo-content">
        <p className={`todo-title ${completed ? "todo-title-done" : ""}`}>
          {title}
        </p>
        <p className="todo-date">{formattedDate}</p>
      </div>

      {/* Delete button */}
      <button
        onClick={handleDelete}
        disabled={isDeleting}
        className="todo-delete-btn"
        aria-label="Delete todo"
      >
        <svg className="delete-icon" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
        </svg>
      </button>
    </div>
  );
}

