
"use client";

import { useState } from "react";
import TodoItem from "./TodoItem";
import type { Todo } from "@/lib/todos";

type Filter = "all" | "active" | "completed";

export default function TodoList({ todos }: { todos: Todo[] }) {
  const [filter, setFilter] = useState<Filter>("all");

  const filtered = todos.filter((t) => {
    if (filter === "active") return !t.completed;
    if (filter === "completed") return t.completed;
    return true;
  });

  const activeCount = todos.filter((t) => !t.completed).length;
  const completedCount = todos.filter((t) => t.completed).length;

  return (
    <div className="todo-list-container">
      {/* Stats bar */}
      <div className="stats-bar">
        <div className="stats-left">
          <span className="stat-badge stat-badge-total">{todos.length} total</span>
          <span className="stat-badge stat-badge-active">{activeCount} active</span>
          <span className="stat-badge stat-badge-done">{completedCount} done</span>
        </div>

        {/* Filter buttons */}
        <div className="filter-group">
          {(["all", "active", "completed"] as Filter[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`filter-btn ${filter === f ? "filter-btn-active" : "filter-btn-inactive"}`}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Todo items */}
      {filtered.length === 0 ? (
        <div className="empty-state">
          <span className="empty-emoji">
            {filter === "completed" ? "🎯" : filter === "active" ? "🎉" : "📝"}
          </span>
          <p className="empty-title">
            {filter === "completed"
              ? "No completed todos yet"
              : filter === "active"
              ? "All done! Nothing active."
              : "No todos yet. Add one above!"}
          </p>
        </div>
      ) : (
        <div className="todo-items-list">
          {filtered.map((todo) => (
            <TodoItem key={todo.id} {...todo} />
          ))}
        </div>
      )}
    </div>
  );
}
