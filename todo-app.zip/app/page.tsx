
import { getAllTodos } from "@/lib/todos";
import AddTodoForm from "./components/AddTodoForm";
import TodoList from "./components/TodoList";

// Force dynamic rendering so we always get fresh data
export const dynamic = "force-dynamic";

export default function HomePage() {
  // ✅ Server-side data fetching — no useEffect, no loading state
  const todos = getAllTodos();

  return (
    <div className="page-container">
      {/* Header */}
      <header className="page-header">
        <div className="header-content">
          <div className="header-icon-wrapper">
            <span className="header-icon">✓</span>
          </div>
          <div>
            <h1 className="page-title">Todo App</h1>
            <p className="page-subtitle">
              Full-stack Next.js — Route Handlers + Server Components
            </p>
          </div>
        </div>
      </header>

      {/* Add form (Client Component) */}
      <AddTodoForm />

      {/* Todo list (Client Component receiving server-fetched data) */}
      <TodoList todos={todos} />

      {/* API info panel */}
      <div className="api-panel">
        <h3 className="api-panel-title">
          <svg className="api-icon" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 6.75L22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3l-4.5 16.5" />
          </svg>
          API Endpoints
        </h3>
        <div className="api-endpoints">
          <div className="endpoint">
            <span className="method method-get">GET</span>
            <code className="endpoint-path">/api/todos</code>
            <span className="endpoint-desc">List all todos</span>
          </div>
          <div className="endpoint">
            <span className="method method-post">POST</span>
            <code className="endpoint-path">/api/todos</code>
            <span className="endpoint-desc">Create a todo</span>
          </div>
          <div className="endpoint">
            <span className="method method-get">GET</span>
            <code className="endpoint-path">/api/todos/[id]</code>
            <span className="endpoint-desc">Get one todo</span>
          </div>
          <div className="endpoint">
            <span className="method method-patch">PATCH</span>
            <code className="endpoint-path">/api/todos/[id]</code>
            <span className="endpoint-desc">Toggle complete</span>
          </div>
          <div className="endpoint">
            <span className="method method-delete">DEL</span>
            <code className="endpoint-path">/api/todos/[id]</code>
            <span className="endpoint-desc">Delete a todo</span>
          </div>
        </div>
      </div>
    </div>
  );
}
