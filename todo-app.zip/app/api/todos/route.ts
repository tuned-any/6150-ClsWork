
import { NextRequest, NextResponse } from "next/server";
import { getAllTodos, addTodo } from "@/lib/todos";

// GET /api/todos — return all todos
export async function GET() {
  const todos = getAllTodos();
  return NextResponse.json(todos);
}

// POST /api/todos — create a new todo
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { title } = body;

    if (!title || typeof title !== "string" || title.trim().length === 0) {
      return NextResponse.json(
        { error: "Title is required and must be a non-empty string" },
        { status: 400 }
      );
    }

    if (title.trim().length > 200) {
      return NextResponse.json(
        { error: "Title must be 200 characters or fewer" },
        { status: 400 }
      );
    }

    const todo = addTodo(title.trim());
    return NextResponse.json(todo, { status: 201 });
  } catch {
    return NextResponse.json(
      { error: "Invalid JSON body" },
      { status: 400 }
    );
  }
}
