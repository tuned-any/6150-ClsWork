
import { NextRequest, NextResponse } from "next/server";
import { getAllTodos, toggleTodo, deleteTodo } from "@/lib/todos";

interface RouteParams {
  params: { id: string };
}

// GET /api/todos/[id] — return a single todo
export async function GET(_request: NextRequest, { params }: RouteParams) {
  const { id } = params;
  const todo = getAllTodos().find((t) => t.id === id);

  if (!todo) {
    return NextResponse.json({ error: "Todo not found" }, { status: 404 });
  }

  return NextResponse.json(todo);
}

// PATCH /api/todos/[id] — toggle completed status
export async function PATCH(_request: NextRequest, { params }: RouteParams) {
  const { id } = params;
  const todo = toggleTodo(id);

  if (!todo) {
    return NextResponse.json({ error: "Todo not found" }, { status: 404 });
  }

  return NextResponse.json(todo);
}

// DELETE /api/todos/[id] — remove a todo
export async function DELETE(_request: NextRequest, { params }: RouteParams) {
  const { id } = params;
  const deleted = deleteTodo(id);

  if (!deleted) {
    return NextResponse.json({ error: "Todo not found" }, { status: 404 });
  }

  return NextResponse.json({ success: true }, { status: 200 });
}
