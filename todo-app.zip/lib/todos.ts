
export interface Todo {
  id: string;
  title: string;
  completed: boolean;
  createdAt: string;
}

// In-memory store (replace with a database in production)
// Using globalThis to persist across hot reloads in dev
const globalForTodos = globalThis as unknown as {
  todos: Todo[] | undefined;
};

export const todos: Todo[] = globalForTodos.todos ?? [
  {
    id: "1",
    title: "Learn Next.js App Router",
    completed: true,
    createdAt: new Date("2026-04-01").toISOString(),
  },
  {
    id: "2",
    title: "Build a full-stack Todo API",
    completed: false,
    createdAt: new Date("2026-04-05").toISOString(),
  },
  {
    id: "3",
    title: "Deploy to Vercel",
    completed: false,
    createdAt: new Date("2026-04-07").toISOString(),
  },
];

globalForTodos.todos = todos;

export function getAllTodos(): Todo[] {
  return [...todos].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export function addTodo(title: string): Todo {
  const todo: Todo = {
    id: crypto.randomUUID(),
    title,
    completed: false,
    createdAt: new Date().toISOString(),
  };
  todos.push(todo);
  return todo;
}

export function toggleTodo(id: string): Todo | null {
  const todo = todos.find((t) => t.id === id);
  if (!todo) return null;
  todo.completed = !todo.completed;
  return todo;
}

export function deleteTodo(id: string): boolean {
  const index = todos.findIndex((t) => t.id === id);
  if (index === -1) return false;
  todos.splice(index, 1);
  return true;
}
