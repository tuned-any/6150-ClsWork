
export interface Post {
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  author: string;
  authorAvatar: string;
  coverImage: string;
  emoji: string;
  readTime: string;
  tags: string[];
  category: string;
  content: string;
}

const posts: Post[] = [
  {
    slug: "getting-started-with-nextjs-app-router",
    title: "Getting Started with Next.js App Router",
    excerpt:
      "Explore the new App Router paradigm in Next.js — layouts, server components, streaming, and more.",
    date: "2026-04-01",
    author: "Tuns",
    authorAvatar: "https://api.dicebear.com/9.x/adventurer/svg?seed=Tuns",
    coverImage: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&q=80",
    emoji: "🚀",
    readTime: "6 min read",
    tags: ["Next.js", "React", "Web Dev"],
    category: "Frameworks",
    content: `
The Next.js App Router represents a fundamental shift in how we build React applications. Introduced in Next.js 13 and stabilized in later versions, it brings React Server Components, nested layouts, and streaming to the mainstream.

## Why the App Router?

The Pages Router served us well, but the App Router unlocks capabilities that were previously impossible or very difficult:

- **Server Components by default** — Components render on the server with zero JavaScript sent to the client unless you opt in with \`"use client"\`.
- **Nested Layouts** — Share UI between routes without re-rendering the shared parts.
- **Streaming & Suspense** — Show instant loading states while slower parts of the page load in the background.
- **Colocation** — Keep components, styles, tests, and utilities right next to the routes that use them.

## File Conventions

The App Router introduces special file names:

| File            | Purpose                              |
|-----------------|--------------------------------------|
| \`layout.tsx\`    | Shared UI that wraps child routes    |
| \`page.tsx\`      | Unique UI for a route                |
| \`loading.tsx\`   | Instant loading skeleton (Suspense)  |
| \`error.tsx\`     | Error boundary for a route segment   |
| \`not-found.tsx\` | 404 UI for a segment                 |

## A Minimal Example

\`\`\`tsx
// app/layout.tsx
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

// app/page.tsx
export default function Home() {
  return <h1>Hello, App Router!</h1>;
}
\`\`\`

That's it — you have a fully server-rendered page with automatic code splitting and optimized streaming.

## What's Next?

In the upcoming articles we'll dive deeper into data fetching, dynamic routes with \`generateStaticParams\`, middleware, and deploying to Vercel. Stay tuned!
    `,
  },
  {
    slug: "mastering-react-server-components",
    title: "Mastering React Server Components",
    excerpt:
      "Learn how RSCs reduce bundle size, simplify data fetching, and change the way you think about React.",
    date: "2026-03-25",
    author: "Tuns",
    authorAvatar: "https://api.dicebear.com/9.x/adventurer/svg?seed=Tuns",
    coverImage: "https://images.unsplash.com/photo-1633356122102-3fe601e05bd2?w=800&q=80",
    emoji: "⚛️",
    readTime: "8 min read",
    tags: ["React", "RSC", "Performance"],
    category: "React",
    content: `
React Server Components (RSCs) are one of the most significant additions to the React ecosystem. They allow components to run exclusively on the server, meaning their code is never shipped to the browser.

## The Mental Model

Think of your component tree as having two zones:

1. **Server zone** — components that fetch data, access databases, and read the file system. They produce HTML that streams to the client.
2. **Client zone** — components that handle interactivity: state, effects, event handlers, browser APIs.

The boundary between them is the \`"use client"\` directive.

## Benefits

- **Zero bundle impact** — A 50 KB charting library used only in a server component adds 0 KB to the client bundle.
- **Direct data access** — No need for API routes or \`useEffect\` waterfalls. Query your database right in the component.
- **Automatic code splitting** — The framework streams HTML and only hydrates the interactive parts.

## Practical Example

\`\`\`tsx
// This component runs ONLY on the server
import { db } from "@/lib/database";

export default async function RecentPosts() {
  const posts = await db.post.findMany({
    orderBy: { createdAt: "desc" },
    take: 5,
  });

  return (
    <ul>
      {posts.map((p) => (
        <li key={p.id}>{p.title}</li>
      ))}
    </ul>
  );
}
\`\`\`

No \`useState\`, no \`useEffect\`, no loading spinner — the data is already there when the HTML arrives.

## When to Use "use client"

Only add \`"use client"\` when you need:
- \`useState\` or \`useReducer\`
- \`useEffect\` or \`useLayoutEffect\`
- Browser-only APIs (\`window\`, \`localStorage\`)
- Event handlers (\`onClick\`, \`onChange\`)

Keep the client boundary as low in the tree as possible to maximize the server-rendered surface area.

## Conclusion

RSCs aren't a replacement for client components — they're a complement. Together they give you the best of both worlds: rich interactivity where you need it and zero-cost rendering everywhere else.
    `,
  },
  {
    slug: "tailwind-css-tips-for-2026",
    title: "Tailwind CSS Tips & Tricks for 2026",
    excerpt:
      "Level up your Tailwind workflow with container queries, the new @starting-style animations, and more.",
    date: "2026-03-18",
    author: "Tuns",
    authorAvatar: "https://api.dicebear.com/9.x/adventurer/svg?seed=Tuns",
    coverImage: "https://images.unsplash.com/photo-1507721999472-8ed4421c4af2?w=800&q=80",
    emoji: "🎨",
    readTime: "5 min read",
    tags: ["CSS", "Tailwind", "Design"],
    category: "Styling",
    content: `
Tailwind CSS has continued to evolve at a rapid pace. Here are some tips to make the most of it in 2026.

## 1. Container Queries Are First-Class

Tailwind now supports container queries out of the box:

\`\`\`html
<div class="@container">
  <div class="@lg:flex @lg:gap-4">
    <!-- Responds to the container width, not the viewport -->
  </div>
</div>
\`\`\`

This is a game-changer for component libraries — your components can adapt to wherever they're placed.

## 2. Grouping with Variants

Chain variants to express complex states concisely:

\`\`\`html
<button class="group">
  <span class="group-hover:text-blue-500 group-focus:underline">
    Hover or focus the button
  </span>
</button>
\`\`\`

## 3. The \`size-*\` Utility

Instead of writing \`w-10 h-10\`, use the shorthand:

\`\`\`html
<div class="size-10 rounded-full bg-blue-500" />
\`\`\`

## 4. Dark Mode with \`prefers-color-scheme\`

Tailwind's \`dark:\` variant works automatically when you set \`darkMode: "media"\`:

\`\`\`html
<div class="bg-white dark:bg-gray-900 text-black dark:text-white" />
\`\`\`

## Conclusion

Tailwind keeps getting more powerful while staying utility-first. These patterns will help you write cleaner, more maintainable styles.
    `,
  },
  {
    slug: "building-accessible-web-apps",
    title: "Building Accessible Web Applications",
    excerpt:
      "Accessibility isn't an afterthought — it's a core feature. Learn how to build inclusive UIs from day one.",
    date: "2026-03-10",
    author: "Tuns",
    authorAvatar: "https://api.dicebear.com/9.x/adventurer/svg?seed=Tuns",
    coverImage: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&q=80",
    emoji: "♿",
    readTime: "7 min read",
    tags: ["Accessibility", "HTML", "UX"],
    category: "UX",
    content: `
Web accessibility (a11y) ensures that everyone — including people with disabilities — can use your application. It's not just the right thing to do; in many jurisdictions, it's the law.

## The Foundation: Semantic HTML

The single most impactful thing you can do is use the right HTML elements:

- Use \`<button>\` for actions, not \`<div onClick>\`
- Use \`<a>\` for navigation
- Use heading levels (\`<h1>\`–\`<h6>\`) in order
- Use \`<nav>\`, \`<main>\`, \`<aside>\`, \`<footer>\` for landmarks

Screen readers and assistive technologies rely heavily on these semantics.

## ARIA: The Escape Hatch

When semantic HTML isn't enough, ARIA attributes fill the gaps:

\`\`\`html
<div role="alert" aria-live="polite">
  Your changes have been saved.
</div>
\`\`\`

But remember: **No ARIA is better than bad ARIA.** Only use it when native elements can't express the meaning.

## Keyboard Navigation

Every interactive element must be reachable and operable via keyboard:

- \`Tab\` to move between focusable elements
- \`Enter\` / \`Space\` to activate
- \`Escape\` to dismiss modals or dropdowns
- Arrow keys for composite widgets (tabs, menus, listboxes)

## Color & Contrast

WCAG 2.1 requires a minimum contrast ratio of **4.5:1** for normal text and **3:1** for large text. Tools like the Chrome DevTools contrast checker make this easy to verify.

## Conclusion

Accessibility is a spectrum, not a checkbox. Start with semantic HTML, layer on ARIA where needed, and test with real assistive technology. Your users will thank you.
    `,
  },
  {
    slug: "typescript-patterns-you-should-know",
    title: "TypeScript Patterns You Should Know",
    excerpt:
      "Discriminated unions, branded types, and the satisfies operator — patterns for production TypeScript.",
    date: "2026-03-02",
    author: "Tuns",
    authorAvatar: "https://api.dicebear.com/9.x/adventurer/svg?seed=Tuns",
    coverImage: "https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=800&q=80",
    emoji: "🔷",
    readTime: "9 min read",
    tags: ["TypeScript", "Patterns", "DX"],
    category: "TypeScript",
    content: `
TypeScript's type system is incredibly expressive. Here are patterns that will make your code safer and more maintainable.

## 1. Discriminated Unions

Model states explicitly instead of using boolean flags:

\`\`\`ts
type State =
  | { status: "idle" }
  | { status: "loading" }
  | { status: "success"; data: User[] }
  | { status: "error"; error: Error };

function render(state: State) {
  switch (state.status) {
    case "idle":    return "Waiting...";
    case "loading": return "Loading...";
    case "success": return state.data.map(u => u.name).join(", ");
    case "error":   return state.error.message;
  }
}
\`\`\`

The compiler guarantees exhaustive handling — add a new status and TypeScript will tell you every place that needs updating.

## 2. The \`satisfies\` Operator

Validate a value against a type while preserving the narrower inferred type:

\`\`\`ts
const routes = {
  home: "/",
  about: "/about",
  blog: "/blog",
} satisfies Record<string, string>;

// routes.home is narrowed to "/" — not just string
\`\`\`

## 3. Branded Types

Prevent mixing up values that share the same primitive type:

\`\`\`ts
type USD = number & { __brand: "USD" };
type EUR = number & { __brand: "EUR" };

function pay(amount: USD) { /* ... */ }

const price = 100 as USD;
pay(price);       // ✅
pay(100 as EUR);  // ❌ Type error!
\`\`\`

## 4. Template Literal Types

Build precise string types:

\`\`\`ts
type EventName = \`on\${Capitalize<"click" | "focus" | "blur">}\`;
// "onClick" | "onFocus" | "onBlur"
\`\`\`

## Conclusion

These patterns help you encode business rules directly in the type system, catching bugs at compile time instead of runtime.
    `,
  },
];

export function getAllPosts(): Post[] {
  return posts.sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );
}

export function getPostBySlug(slug: string): Post | undefined {
  return posts.find((p) => p.slug === slug);
}

export function getAllSlugs(): string[] {
  return posts.map((p) => p.slug);
}

