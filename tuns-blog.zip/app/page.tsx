
import Link from "next/link";
import Image from "next/image";
import { getAllPosts } from "@/lib/posts";

export default function HomePage() {
  const allPosts = getAllPosts();
  const featured = allPosts[0];
  const rest = allPosts.slice(1);

  return (
    <div className="space-y-20 animate-fade-in-up">
      {/* ── Hero Section ── */}
      <section className="relative overflow-hidden rounded-3xl hero-gradient px-8 py-20 text-center text-white shadow-2xl shadow-indigo-500/20">
        {/* Decorative blobs */}
        <div className="absolute -top-24 -left-24 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -bottom-32 -right-32 h-80 w-80 rounded-full bg-white/10 blur-3xl" />

        <div className="relative space-y-6">
          <span className="inline-block rounded-full bg-white/15 px-4 py-1.5 text-sm font-medium backdrop-blur-sm">
            ✦ Welcome to Tuns Blog
          </span>
          <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl">
            Ideas, Code &<br />
            <span className="bg-gradient-to-r from-amber-200 to-yellow-100 bg-clip-text text-transparent">
              Modern Web Dev
            </span>
          </h1>
          <p className="mx-auto max-w-lg text-lg text-white/80">
            Exploring Next.js, React, TypeScript, and modern tooling —
            one beautifully crafted article at a time.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <Link
              href="/posts"
              className="rounded-full bg-white px-6 py-2.5 text-sm font-semibold text-indigo-700 shadow-lg transition-all hover:shadow-xl hover:brightness-105"
            >
              Browse All Posts →
            </Link>
            <Link
              href={`/posts/${featured.slug}`}
              className="rounded-full border border-white/30 px-6 py-2.5 text-sm font-semibold text-white backdrop-blur-sm transition-all hover:bg-white/10"
            >
              Read Latest
            </Link>
          </div>
        </div>
      </section>

      {/* ── Featured Post ── */}
      <section className="space-y-6">
        <div className="flex items-center gap-3">
          <span className="h-px flex-1 bg-gradient-to-r from-transparent via-indigo-300 to-transparent dark:via-indigo-700" />
          <h2 className="text-sm font-semibold uppercase tracking-widest text-indigo-600 dark:text-indigo-400">
            Featured Article
          </h2>
          <span className="h-px flex-1 bg-gradient-to-r from-transparent via-indigo-300 to-transparent dark:via-indigo-700" />
        </div>

        <Link
          href={`/posts/${featured.slug}`}
          className="group gradient-border block overflow-hidden rounded-2xl shadow-lg transition-all hover:shadow-xl"
        >
          <div className="flex flex-col md:flex-row">
            {/* Image */}
            <div className="relative h-64 w-full overflow-hidden md:h-auto md:w-1/2">
              <Image
                src={featured.coverImage}
                alt={featured.title}
                fill
                className="object-cover img-zoom"
                sizes="(max-width: 768px) 100vw, 50vw"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
              <span className="absolute bottom-4 left-4 rounded-full bg-white/20 px-3 py-1 text-xs font-semibold text-white backdrop-blur-md">
                {featured.category}
              </span>
            </div>

            {/* Content */}
            <div className="flex flex-col justify-center p-8 md:w-1/2">
              <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                <Image
                  src={featured.authorAvatar}
                  alt={featured.author}
                  width={24}
                  height={24}
                  className="rounded-full"
                />
                <span>{featured.author}</span>
                <span>·</span>
                <time dateTime={featured.date}>{featured.date}</time>
                <span>·</span>
                <span>{featured.readTime}</span>
              </div>
              <h3 className="mt-3 text-2xl font-bold tracking-tight transition-colors group-hover:text-indigo-600">
                {featured.title}
              </h3>
              <p className="mt-2 text-gray-600 dark:text-gray-400 leading-relaxed">
                {featured.excerpt}
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {featured.tags.map((tag) => (
                  <span key={tag} className="tag-pill tag-pill-purple">{tag}</span>
                ))}
              </div>
              <span className="mt-6 inline-flex items-center gap-1 text-sm font-semibold text-indigo-600 transition-all group-hover:gap-2 dark:text-indigo-400">
                Read article <span>→</span>
              </span>
            </div>
          </div>
        </Link>
      </section>

      {/* ── Post Grid ── */}
      <section className="space-y-6">
        <h2 className="text-2xl font-bold tracking-tight">More Articles</h2>
        <div className="grid gap-6 sm:grid-cols-2">
          {rest.map((post, i) => (
            <Link
              key={post.slug}
              href={`/posts/${post.slug}`}
              className="card-hover group overflow-hidden rounded-2xl border border-gray-200/80 bg-white shadow-sm dark:border-gray-800/80 dark:bg-gray-900"
              style={{ animationDelay: `${i * 100}ms` }}
            >
              {/* Card image */}
              <div className="relative h-48 w-full overflow-hidden">
                <Image
                  src={post.coverImage}
                  alt={post.title}
                  fill
                  className="object-cover img-zoom"
                  sizes="(max-width: 640px) 100vw, 50vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
                <span className="absolute top-3 right-3 rounded-full bg-white/20 px-2.5 py-0.5 text-xs font-semibold text-white backdrop-blur-md">
                  {post.category}
                </span>
              </div>

              {/* Card body */}
              <div className="p-5 space-y-3">
                <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                  <Image
                    src={post.authorAvatar}
                    alt={post.author}
                    width={20}
                    height={20}
                    className="rounded-full"
                  />
                  <span>{post.author}</span>
                  <span>·</span>
                  <time dateTime={post.date}>{post.date}</time>
                  <span>·</span>
                  <span>{post.readTime}</span>
                </div>
                <h3 className="text-lg font-bold leading-snug transition-colors group-hover:text-indigo-600">
                  {post.title}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2">
                  {post.excerpt}
                </p>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {post.tags.map((tag) => (
                    <span key={tag} className="tag-pill tag-pill-blue text-[11px]">{tag}</span>
                  ))}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* ── Newsletter CTA ── */}
      <section className="rounded-2xl bg-gradient-to-br from-gray-900 to-gray-800 p-10 text-center text-white shadow-2xl dark:from-gray-800 dark:to-gray-900">
        <h2 className="text-2xl font-bold">Stay in the loop</h2>
        <p className="mt-2 text-gray-400">Get new articles delivered straight to your inbox. No spam, ever.</p>
        <div className="mx-auto mt-6 flex max-w-md gap-2">
          <input
            type="email"
            placeholder="your@email.com"
            className="flex-1 rounded-lg border border-gray-700 bg-gray-800 px-4 py-2.5 text-sm text-white placeholder-gray-500 outline-none transition-colors focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
          />
          <button className="rounded-lg bg-indigo-500 px-5 py-2.5 text-sm font-semibold text-white transition-all hover:bg-indigo-600 hover:shadow-lg hover:shadow-indigo-500/25">
            Subscribe
          </button>
        </div>
      </section>
    </div>
  );
}
