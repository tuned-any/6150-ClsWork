
import Link from "next/link";
import Image from "next/image";
import { getAllPosts } from "@/lib/posts";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "All Posts | Tuns Blog",
};

export const dynamic = "force-static";

export default function PostsPage() {
  const posts = getAllPosts();

  return (
    <div className="space-y-10 animate-fade-in-up">
      {/* Page header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-600 to-purple-700 px-8 py-12 text-white shadow-xl shadow-indigo-500/15">
        <div className="absolute -top-20 -right-20 h-56 w-56 rounded-full bg-white/10 blur-2xl" />
        <div className="absolute -bottom-16 -left-16 h-48 w-48 rounded-full bg-white/10 blur-2xl" />
        <div className="relative">
          <h1 className="text-4xl font-extrabold tracking-tight">All Posts</h1>
          <p className="mt-2 text-indigo-200">
            {posts.length} articles and counting — dive in.
          </p>
        </div>
      </div>

      {/* Posts list */}
      <div className="space-y-5">
        {posts.map((post, i) => (
          <Link
            key={post.slug}
            href={`/posts/${post.slug}`}
            className="card-hover group flex flex-col overflow-hidden rounded-xl border border-gray-200/80 bg-white shadow-sm sm:flex-row dark:border-gray-800/80 dark:bg-gray-900"
            style={{ animationDelay: `${i * 80}ms` }}
          >
            {/* Thumbnail */}
            <div className="relative h-48 w-full shrink-0 overflow-hidden sm:h-auto sm:w-56">
              <Image
                src={post.coverImage}
                alt={post.title}
                fill
                className="object-cover img-zoom"
                sizes="(max-width: 640px) 100vw, 224px"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/20 to-transparent sm:bg-gradient-to-r" />
            </div>

            {/* Content */}
            <div className="flex flex-col justify-center p-5 sm:p-6">
              <div className="flex flex-wrap items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                <span className="rounded-full bg-indigo-50 px-2 py-0.5 font-semibold text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
                  {post.category}
                </span>
                <time dateTime={post.date}>{post.date}</time>
                <span>·</span>
                <span>{post.readTime}</span>
              </div>
              <h2 className="mt-2 text-xl font-bold transition-colors group-hover:text-indigo-600">
                {post.title}
              </h2>
              <p className="mt-1.5 text-sm text-gray-600 dark:text-gray-400 line-clamp-2">
                {post.excerpt}
              </p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {post.tags.map((tag) => (
                  <span key={tag} className="tag-pill tag-pill-blue text-[11px]">{tag}</span>
                ))}
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
