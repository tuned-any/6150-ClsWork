
import { notFound } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { getAllSlugs, getPostBySlug, getAllPosts } from "@/lib/posts";
import type { Metadata } from "next";

// ✅ Pre-render all post pages at build time
export function generateStaticParams() {
  return getAllSlugs().map((slug) => ({ slug }));
}

export function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Metadata {
  const post = getPostBySlug(params.slug);
  if (!post) return { title: "Post Not Found" };
  return {
    title: `${post.title} | Tuns Blog`,
    description: post.excerpt,
  };
}

export default function PostPage({
  params,
}: {
  params: { slug: string };
}) {
  const post = getPostBySlug(params.slug);
  if (!post) notFound();

  // Get related posts (same category, excluding current)
  const related = getAllPosts()
    .filter((p) => p.slug !== post.slug)
    .slice(0, 2);

  return (
    <article className="animate-fade-in-up">
      {/* Back link */}
      <Link
        href="/posts"
        className="inline-flex items-center gap-1.5 text-sm font-medium text-gray-500 transition-colors hover:text-indigo-600"
      >
        <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
        </svg>
        Back to all posts
      </Link>

      {/* Hero image */}
      <div className="relative mt-6 h-72 w-full overflow-hidden rounded-2xl shadow-xl sm:h-96">
        <Image
          src={post.coverImage}
          alt={post.title}
          fill
          priority
          className="object-cover"
          sizes="(max-width: 768px) 100vw, 1024px"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />

        {/* Overlay content */}
        <div className="absolute bottom-0 left-0 right-0 p-8">
          <span className="inline-block rounded-full bg-white/20 px-3 py-1 text-xs font-semibold text-white backdrop-blur-md">
            {post.category}
          </span>
          <h1 className="mt-3 text-3xl font-extrabold leading-tight text-white sm:text-4xl drop-shadow-lg">
            {post.title}
          </h1>
        </div>
      </div>

      {/* Meta bar */}
      <div className="mt-6 flex flex-wrap items-center gap-4 rounded-xl border border-gray-200/80 bg-white p-4 shadow-sm dark:border-gray-800/80 dark:bg-gray-900">
        <div className="flex items-center gap-2.5">
          <Image
            src={post.authorAvatar}
            alt={post.author}
            width={36}
            height={36}
            className="rounded-full ring-2 ring-indigo-100 dark:ring-indigo-900"
          />
          <div>
            <p className="text-sm font-semibold">{post.author}</p>
            <p className="text-xs text-gray-500">Author</p>
          </div>
        </div>
        <span className="h-8 w-px bg-gray-200 dark:bg-gray-700" />
        <div>
          <p className="text-sm font-semibold"><time dateTime={post.date}>{post.date}</time></p>
          <p className="text-xs text-gray-500">Published</p>
        </div>
        <span className="h-8 w-px bg-gray-200 dark:bg-gray-700" />
        <div>
          <p className="text-sm font-semibold">{post.readTime}</p>
          <p className="text-xs text-gray-500">Read time</p>
        </div>
        <div className="ml-auto flex flex-wrap gap-2">
          {post.tags.map((tag) => (
            <span key={tag} className="tag-pill tag-pill-purple">{tag}</span>
          ))}
        </div>
      </div>

      {/* Article body */}
      <div className="mt-10 prose prose-lg prose-gray max-w-none dark:prose-invert prose-headings:font-bold prose-headings:tracking-tight prose-a:text-indigo-600 prose-a:no-underline hover:prose-a:underline">
        <div
          dangerouslySetInnerHTML={{ __html: formatContent(post.content) }}
        />
      </div>

      {/* Share / action bar */}
      <div className="mt-12 flex items-center justify-between rounded-xl border border-gray-200/80 bg-gradient-to-r from-gray-50 to-white p-5 dark:border-gray-800/80 dark:from-gray-900 dark:to-gray-900">
        <p className="text-sm text-gray-500">Enjoyed this article? Share it with your friends.</p>
        <div className="flex gap-2">
          <button className="rounded-lg bg-gray-100 px-3 py-2 text-xs font-medium text-gray-700 transition-colors hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700">
            Copy Link
          </button>
          <button className="rounded-lg bg-indigo-50 px-3 py-2 text-xs font-medium text-indigo-700 transition-colors hover:bg-indigo-100 dark:bg-indigo-900/30 dark:text-indigo-300 dark:hover:bg-indigo-900/50">
            Share on X
          </button>
        </div>
      </div>

      {/* Related posts */}
      {related.length > 0 && (
        <section className="mt-16 space-y-6">
          <h2 className="text-2xl font-bold tracking-tight">More to Read</h2>
          <div className="grid gap-5 sm:grid-cols-2">
            {related.map((p) => (
              <Link
                key={p.slug}
                href={`/posts/${p.slug}`}
                className="card-hover group overflow-hidden rounded-xl border border-gray-200/80 bg-white shadow-sm dark:border-gray-800/80 dark:bg-gray-900"
              >
                <div className="relative h-40 w-full overflow-hidden">
                  <Image
                    src={p.coverImage}
                    alt={p.title}
                    fill
                    className="object-cover img-zoom"
                    sizes="(max-width: 640px) 100vw, 50vw"
                  />
                </div>
                <div className="p-4">
                  <p className="text-xs text-gray-500">{p.date} · {p.readTime}</p>
                  <h3 className="mt-1 font-bold transition-colors group-hover:text-indigo-600">{p.title}</h3>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </article>
  );
}

/** Simple content formatter — replace with remark/MDX in production */
function formatContent(raw: string): string {
  return raw
    .trim()
    .replace(
      /^## (.+)$/gm,
      '<h2 class="text-2xl font-bold mt-10 mb-4 bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent dark:from-indigo-400 dark:to-purple-400">$1</h2>'
    )
    .replace(
      /^### (.+)$/gm,
      '<h3 class="text-xl font-semibold mt-8 mb-3">$1</h3>'
    )
    .replace(
      /```(\w+)?\n([\s\S]*?)```/g,
      '<pre class="overflow-x-auto rounded-xl bg-slate-900 p-5 text-sm leading-relaxed text-slate-100 my-6 border border-slate-700/50 shadow-lg"><code>$2</code></pre>'
    )
    .replace(
      /`([^`]+)`/g,
      '<code class="rounded-md bg-indigo-50 px-1.5 py-0.5 text-sm font-medium text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300">$1</code>'
    )
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(
      /\|(.+)\|\n\|[-| ]+\|\n((\|.+\|\n?)+)/g,
      (_match: string, headerRow: string, bodyRows: string) => {
        const headers = headerRow
          .split("|")
          .filter(Boolean)
          .map(
            (h: string) =>
              `<th class="border border-gray-200 bg-gray-50 px-4 py-2.5 text-left text-sm font-semibold dark:border-gray-700 dark:bg-gray-800/50">${h.trim()}</th>`
          )
          .join("");
        const rows = bodyRows
          .trim()
          .split("\n")
          .map((row: string) => {
            const cells = row
              .split("|")
              .filter(Boolean)
              .map(
                (c: string) =>
                  `<td class="border border-gray-200 px-4 py-2.5 text-sm dark:border-gray-700">${c.trim()}</td>`
              )
              .join("");
            return `<tr class="hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors">${cells}</tr>`;
          })
          .join("");
        return `<div class="my-6 overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm"><table class="w-full border-collapse"><thead><tr>${headers}</tr></thead><tbody>${rows}</tbody></table></div>`;
      }
    )
    .replace(
      /^(\d+)\. (.+)$/gm,
      '<li class="ml-6 list-decimal py-0.5">$2</li>'
    )
    .replace(
      /^- (.+)$/gm,
      '<li class="ml-6 list-disc py-0.5">$1</li>'
    )
    .replace(
      /\n\n/g,
      '</p><p class="my-4 leading-relaxed text-gray-700 dark:text-gray-300">'
    );
}
