
export default function PostLoading() {
  return (
    <div className="space-y-8">
      {/* Back link */}
      <div className="skeleton h-4 w-32 rounded-md" />

      {/* Hero image skeleton */}
      <div className="skeleton h-72 w-full rounded-2xl sm:h-96" />

      {/* Meta bar */}
      <div className="flex items-center gap-4 rounded-xl border border-gray-200/60 p-4 dark:border-gray-800/60">
        <div className="flex items-center gap-2.5">
          <div className="skeleton size-9 rounded-full" />
          <div className="space-y-1.5">
            <div className="skeleton h-3.5 w-16 rounded" />
            <div className="skeleton h-2.5 w-10 rounded" />
          </div>
        </div>
        <div className="h-8 w-px bg-gray-200 dark:bg-gray-700" />
        <div className="space-y-1.5">
          <div className="skeleton h-3.5 w-20 rounded" />
          <div className="skeleton h-2.5 w-14 rounded" />
        </div>
        <div className="h-8 w-px bg-gray-200 dark:bg-gray-700" />
        <div className="space-y-1.5">
          <div className="skeleton h-3.5 w-16 rounded" />
          <div className="skeleton h-2.5 w-12 rounded" />
        </div>
        <div className="ml-auto flex gap-2">
          <div className="skeleton h-6 w-14 rounded-full" />
          <div className="skeleton h-6 w-16 rounded-full" />
          <div className="skeleton h-6 w-12 rounded-full" />
        </div>
      </div>

      {/* Content skeleton */}
      <div className="space-y-4 pt-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="skeleton h-4 rounded" style={{ width: `${75 + Math.random() * 25}%` }} />
        ))}
        <div className="skeleton h-7 w-2/5 rounded-md mt-8" />
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={`b${i}`} className="skeleton h-4 rounded" style={{ width: `${65 + Math.random() * 35}%` }} />
        ))}
        <div className="skeleton h-44 w-full rounded-xl my-4" />
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={`c${i}`} className="skeleton h-4 rounded" style={{ width: `${60 + Math.random() * 40}%` }} />
        ))}
      </div>
    </div>
  );
}
