
import Link from "next/link";

export default function PostNotFound() {
  return (
    <div className="flex flex-col items-center justify-center gap-6 py-24 text-center animate-fade-in-up">
      <div className="flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-indigo-100 to-purple-100 text-5xl shadow-lg shadow-indigo-500/10 dark:from-indigo-900/30 dark:to-purple-900/30">
        📭
      </div>
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight">Post Not Found</h1>
        <p className="mt-2 text-gray-500 dark:text-gray-400">
          The article you're looking for doesn't exist or has been moved.
        </p>
      </div>
      <Link
        href="/posts"
        className="rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 px-6 py-2.5 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 transition-all hover:shadow-xl hover:brightness-110"
      >
        ← Browse All Posts
      </Link>
    </div>
  );
}
