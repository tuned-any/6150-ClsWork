
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import Link from "next/link";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Tuns Blog",
  description: "A modern blog built with Next.js App Router",
};

function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-gray-200/60 bg-white/70 backdrop-blur-xl dark:border-gray-800/60 dark:bg-gray-950/70">
      <nav className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5 group">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 text-sm font-bold text-white shadow-md shadow-indigo-500/20 transition-transform group-hover:scale-105">
            T
          </span>
          <span className="text-lg font-bold tracking-tight text-gray-900 dark:text-white">
            Tuns<span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">Blog</span>
          </span>
        </Link>

        {/* Nav links */}
        <ul className="flex items-center gap-1 text-sm font-medium">
          <li>
            <Link
              href="/"
              className="rounded-lg px-3.5 py-2 text-gray-600 transition-all hover:bg-gray-100 hover:text-gray-900 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
            >
              Home
            </Link>
          </li>
          <li>
            <Link
              href="/posts"
              className="rounded-lg px-3.5 py-2 text-gray-600 transition-all hover:bg-gray-100 hover:text-gray-900 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
            >
              Posts
            </Link>
          </li>
          <li>
            <Link
              href="/posts"
              className="ml-2 rounded-lg bg-gradient-to-r from-indigo-500 to-purple-600 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-indigo-500/25 transition-all hover:shadow-lg hover:shadow-indigo-500/30 hover:brightness-110"
            >
              Subscribe
            </Link>
          </li>
        </ul>
      </nav>
    </header>
  );
}

function Footer() {
  return (
    <footer className="mt-20 border-t border-gray-200/60 bg-gray-50 dark:border-gray-800/60 dark:bg-gray-900/50">
      <div className="mx-auto max-w-5xl px-6 py-12">
        <div className="flex flex-col items-center gap-6 sm:flex-row sm:justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 text-xs font-bold text-white">
              T
            </span>
            <span className="font-bold text-gray-900 dark:text-white">
              Tuns<span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">Blog</span>
            </span>
          </div>

          {/* Links */}
          <div className="flex gap-6 text-sm text-gray-500">
            <Link href="/" className="hover:text-indigo-600 transition-colors">Home</Link>
            <Link href="/posts" className="hover:text-indigo-600 transition-colors">Posts</Link>
            <a href="https://github.com" className="hover:text-indigo-600 transition-colors">GitHub</a>
            <a href="https://twitter.com" className="hover:text-indigo-600 transition-colors">Twitter</a>
          </div>
        </div>

        <div className="mt-8 border-t border-gray-200 pt-6 text-center text-xs text-gray-400 dark:border-gray-800">
          © {new Date().getFullYear()} Tuns Blog. Built with Next.js App Router & Tailwind CSS.
        </div>
      </div>
    </footer>
  );
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body
        className={`${inter.className} text-gray-900 antialiased dark:text-gray-100`}
      >
        <Navbar />
        <main className="mx-auto max-w-5xl px-6 py-10">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}
